import AppHeader from "../AppHeader";

function CreateTraining() {
  return (
    <>
      <AppHeader />
      <p>dfdfdfdf</p>
    </>
  );
}

export default CreateTraining;
